/* Generated automatically. */
static const char configuration_arguments[] = "/home/arnd/git/gcc/configure --target=x86_64-linux --enable-targets=all --prefix=/opt/crosstool/gcc-4.9.4-nolibc/x86_64-linux --enable-languages=c --without-headers --disable-bootstrap --disable-nls --disable-threads --disable-shared --disable-libmudflap --disable-libssp --disable-libgomp --disable-decimal-float --disable-libquadmath --disable-libatomic --disable-libcc1 --disable-libmpx --enable-checking=release";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "generic" }, { "arch", "x86-64" } };
